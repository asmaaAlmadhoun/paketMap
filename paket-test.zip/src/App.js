import 'bootstrap/dist/css/bootstrap.css';
import Home from './home';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <Home />
      </header>
    </div>
  );
}

export default App;
